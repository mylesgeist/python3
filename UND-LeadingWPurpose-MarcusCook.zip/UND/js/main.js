// Load HTML component into placeholder divs by ID
async function loadComponent(id, url) {
  try {
    const response = await fetch(url);
    const html = await response.text();
    const container = document.getElementById(id);
    if (container) {
      container.innerHTML = html;
    } else {
      throw new Error(`Element with id "${id}" not found.`);
    }
  } catch (error) {
    console.error(`Error loading component ${id}:`, error);
  }
}

// Load components, then initialize related JS
document.addEventListener('DOMContentLoaded', () => {
  loadComponent('header', 'components/header.html').then(() => {
    // ✅ Burger menu toggle setup
    const toggleButton = document.getElementById('menu-toggle');
    const navLinks = document.getElementById('nav-links');

    if (toggleButton && navLinks) {
      // Hide menu by default in case CSS didn't do it (safety net)
      if (window.innerWidth <= 768) {
        navLinks.classList.remove('active');
      }

      toggleButton.addEventListener('click', () => {
        const isOpen = navLinks.classList.toggle('active');
        toggleButton.setAttribute('aria-expanded', isOpen);
      });

      // Optional: hide nav when resizing back to desktop
      window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
          navLinks.classList.remove('active');
          toggleButton.setAttribute('aria-expanded', false);
        }
      });
    }
  });

  loadComponent('footer', 'components/footer.html');
  loadComponent('president', 'components/president.html');

  loadComponent('posts', 'components/posts.html').then(() => {
    loadPosts();

    const input = document.getElementById('post-filter-input');
    const searchButton = document.getElementById('post-filter-button');
    const clearButton = document.getElementById('post-clear-button');
    const noPostsMessage = document.getElementById('no-posts-message');

    const filterPosts = () => {
      const term = input.value.trim().toLowerCase();
      filteredPosts = allPosts.filter(post => {
        const searchable = [
          post.message,
          post.author,
          post.username,
          post.location
        ]
          .filter(Boolean)
          .map(str => str.toLowerCase())
          .join(' ');
        return searchable.includes(term);
      });

      currentPage = 1;
      renderPosts(filteredPosts);
    };

    if (input && searchButton) {
      searchButton.addEventListener('click', filterPosts);

      input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          event.preventDefault();
          filterPosts();
        }
      });
    }

    if (input && clearButton) {
      clearButton.addEventListener('click', () => {
        input.value = '';
        input.focus();
        filteredPosts = [];
        currentPage = 1;
        renderPosts(allPosts);
        if (noPostsMessage) noPostsMessage.hidden = true;
      });
    }
  });
});
