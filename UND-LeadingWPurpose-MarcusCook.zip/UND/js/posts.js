let allPosts = [];
let filteredPosts = [];
let currentPage = 1;
let postsPerPage = 5;

async function loadPosts() {
  const container = document.getElementById('post-list');
  if (!container) return;

  try {
    const today = new Date();
    const fetchChunks = [];

    for (let i = 0; i < 9; i += 3) {
      const from = new Date(today);
      const to = new Date(today);

      from.setDate(today.getDate() - (i + 2));
      to.setDate(today.getDate() - i);

      const fromStr = from.toISOString().split('T')[0];
      const toStr = to.toISOString().split('T')[0];

      const url = `https://apps.und.edu/demo/public/index.php/post?from=${fromStr}&to=${toStr}`;
      fetchChunks.push(fetch(url).then(res => res.json()));
    }

    const results = await Promise.all(fetchChunks);
    allPosts = results.flat();
    allPosts.sort((a, b) => new Date(b.date) - new Date(a.date));

    renderPosts(allPosts);
  } catch (error) {
    console.error('Error loading posts:', error);
  }
}

function renderPosts(posts) {
  const container = document.getElementById('post-list');
  const noPostsMessage = document.getElementById('no-posts-message');
  if (!container) return;

  const start = (currentPage - 1) * postsPerPage;
  const end = start + postsPerPage;
  const paginatedPosts = posts.slice(start, end);

  if (paginatedPosts.length === 0) {
    container.innerHTML = '';
    if (noPostsMessage) noPostsMessage.hidden = false;
    renderPagination([]);
    return;
  } else {
    if (noPostsMessage) noPostsMessage.hidden = true;
  }

  container.innerHTML = paginatedPosts.map(post => {
    const displayName = post.author?.trim() || `@${post.username}`;
    return `
      <article class="post">
        <header>
          <h3>${displayName} — ${new Date(post.date).toLocaleString()}</h3>
          <p>${post.location}</p>
        </header>
        <p>${post.message}</p>
        <footer>
          ❤️ ${post.likes} &nbsp;&nbsp; 🔁 ${post.reposts}
        </footer>
      </article>
    `;
  }).join('');

  renderPagination(posts);
}

function renderPagination(posts) {
  const paginations = document.querySelectorAll('.pagination');
  const totalPages = Math.ceil(posts.length / postsPerPage);

  paginations.forEach(pagination => {
    pagination.innerHTML = `
      <div class="pagination-left">
        <p>Page ${currentPage} of ${totalPages || 1}</p>
        <button class="page-nav" ${currentPage === 1 ? 'disabled' : ''} data-direction="prev">&laquo; Prev</button>
        <input type="number" id="page-number-input" min="1" max="${totalPages}" value="${currentPage}" style="width: 3em;">
        <button class="page-nav" ${currentPage === totalPages ? 'disabled' : ''} data-direction="next">Next &raquo;</button>
      </div>
      <div class="pagination-right">
        <label for="posts-per-page-select">Posts per page:</label>
        <select id="posts-per-page-select" aria-label="Select number of posts per page">
          <option value="5" ${postsPerPage === 5 ? 'selected' : ''}>5</option>
          <option value="10" ${postsPerPage === 10 ? 'selected' : ''}>10</option>
          <option value="15" ${postsPerPage === 15 ? 'selected' : ''}>15</option>
        </select>
      </div>
    `;
  });

  document.querySelectorAll('.page-nav').forEach(btn => {
    btn.addEventListener('click', () => {
      const direction = btn.getAttribute('data-direction');
      const postsToShow = filteredPosts.length ? filteredPosts : allPosts;
      const totalPages = Math.ceil(postsToShow.length / postsPerPage);

      if (direction === 'prev' && currentPage > 1) {
        currentPage--;
      } else if (direction === 'next' && currentPage < totalPages) {
        currentPage++;
      }

      renderPosts(postsToShow);
    });
  });

  document.querySelectorAll('#page-number-input').forEach(input => {
    input.addEventListener('change', () => {
      const postsToShow = filteredPosts.length ? filteredPosts : allPosts;
      const totalPages = Math.ceil(postsToShow.length / postsPerPage);
      const val = parseInt(input.value);
      if (!isNaN(val) && val >= 1 && val <= totalPages) {
        currentPage = val;
        renderPosts(postsToShow);
      } else {
        input.value = currentPage;
      }
    });
  });

  const perPageSelect = document.getElementById('posts-per-page-select');
  if (perPageSelect) {
    perPageSelect.addEventListener('change', () => {
      postsPerPage = parseInt(perPageSelect.value);
      currentPage = 1;
      const data = filteredPosts.length ? filteredPosts : allPosts;
      renderPosts(data);
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('post-filter-input');
  const searchButton = document.getElementById('post-filter-button');
  const clearButton = document.getElementById('post-clear-button');
  const noPostsMessage = document.getElementById('no-posts-message');

  const filterPosts = () => {
    const term = input.value.trim().toLowerCase();
    filteredPosts = allPosts.filter(post => {
      const searchable = [
        post.message,
        post.author,
        post.username,
        post.location
      ]
        .filter(Boolean)
        .map(str => str.toLowerCase())
        .join(' ');
      return searchable.includes(term);
    });

    currentPage = 1;
    renderPosts(filteredPosts);
  };

  if (input && searchButton) {
    searchButton.addEventListener('click', filterPosts);

    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        filterPosts();
      }
    });
  }

  if (input && clearButton) {
    clearButton.addEventListener('click', () => {
      input.value = '';                       // ✅ clears the visible input
      input.focus();                          // optional: re-focus input
      filteredPosts = [];
      currentPage = 1;
      renderPosts(allPosts);
      if (noPostsMessage) noPostsMessage.hidden = true;
    });
  }
});
