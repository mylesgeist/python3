## UND Showcase Project: Planning Summary

### ✨ Project Goal

Build a mini-site for UND’s *"Leading with Purpose"* campaign to demonstrate front-end skills in:

- Semantic HTML5
- CSS (with SCSS)
- Vanilla JavaScript (ES6+)
- Accessibility (WCAG/508)
- SEO & UND branding
- Client-side API interaction
- Responsive, mobile-first design

---

### 📊 Key Features

#### Header & Footer

- UND logo
- 5 navigation links (from appendix)
- Mobile burger menu
- Skip links, keyboard navigation
- Screen reader support

#### President’s Endorsement Section

- Semantic layout (section, figure, article)
- President photo on **right side**
- Call-to-action button (linked)
- Accessible image and heading structure

#### Post List Section

- Fetch posts from UND JSON API
- Limit to **current day and previous day** only
- Sort by date descending
- Limit to **10 most recent posts**
- Filter posts by content (search input)
- Dynamically create DOM elements
- Full tab and ARIA accessibility

---

### 🔧 Tools & Technologies

- HTML5 + Semantic tags
- SCSS with Gulp compiler
- JavaScript (Vanilla ES6+)
- Optional jQuery (not currently used)
- Gulp build system (SCSS -> CSS, minify)
- Git for version control
- GitHub for submission
- README.md for build/setup instructions

---

### 📂 Project File Structure (Component-Based)

```
project/
├── components/
│   ├── header.html
│   ├── footer.html
│   ├── president.html
│   └── posts.html
├── css/
│   ├── main.scss
│   ├── _variables.scss
│   ├── _president.scss
│   └── ...
├── js/
│   ├── main.js
│   └── posts.js
├── images/
│   └── president.jpg
├── index.html
├── gulpfile.js
└── README.md
```

---

### 📅 Upcoming Implementation Tasks

-

---

### 📜 Notes for Submission

- Submit via GitHub or share link
- Include full unbuilt source, assets, and config
- Include README with build/setup instructions
- Code must demonstrate HTML/CSS/JS best practices

