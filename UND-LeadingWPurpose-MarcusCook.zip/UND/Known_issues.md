# Known Issues

- Desktop menu alignment could be tightened with more time. The menu is static and not dynamic
- Minor layout spacing tweaks pending
