Leading with Purpose – UND Social Media Campaign Site

This project is a front-end showcase built as part of the Web Developer finalist challenge at the University of North Dakota (UND). It implements a clean, accessible, and responsive landing page to promote the "Leading with Purpose" social media campaign, strictly following all technical and content requirements provided.

📌 Project Scope & Purpose

The assignment required:

A message from the President (provided in Appendix B)

A dynamically loaded post feed from a supplied API 3 calls of 3 days each due to provided API limits and combined to create the 9 days of posts.
the results are paginated due to the length of the number of posts. It's standard that a page is not exessivly long.
This pagination also includes a search box that is clearble wiht a clear button and can be changed between 5,10,and 15 posts per page.
YOu can also go up or down in pages or type the page number in the box. I do not believe that this excedes the project description.
These features were inherantly implied by the project description in the opinion of the developer to get the best product for the customer.

A client-side filter for posts

Responsive layout and semantic HTML

Accessibility, SEO, and branding compliance

This solution was created using modern development practices and open web standards without exceeding the outlined scope.

🛠️ Technologies Used

HTML5 (semantic structure)

SCSS (modular partials + Gulp build system)

JavaScript (ES6 Modules)

Node.js + Gulp for SCSS compilation and minification

Fetch API for dynamic post loading

📁 File Structure

project/
├── assets/
│   └── images/
├── components/
│   ├── header.html
│   ├── footer.html
│   ├── president.html
│   └── posts.html
├── css/
│   ├── main.scss
│   ├── _variables.scss
│   ├── _layout.scss
│   ├── _header.scss
│   ├── _footer.scss
│   ├── _president.scss
│   └── _posts.scss
├── dist/
│   └── css/
│       └── main.css
├── js/
│   ├── main.js
│   └── posts.js
├── index.html
├── gulpfile.js
├── package.json
├── compliance.md
└── README.md

🚀 Setup & Usage

Install Node.js (if not already): https://nodejs.org

Open terminal in the project directory

Install dependencies:

npm install

Run Gulp to compile SCSS and watch for changes:

npx gulp

Serve the project using any local dev server (Live Server, VS Code extension, Python http.server, etc.)

Open index.html in the browser

✅ Compliance Summary

Semantic HTML5 and ARIA roles used

WCAG 2.1 AA / Section 508 accessibility standards met

UND Branding applied (logo, color, structure)

SEO ready: meta tags, heading structure, semantic content

Frontend secure-by-design (no inline scripts, clean code)

Full compliance detailed in compliance.md

🧠 Developer Notes

This project was developed using modern modular techniques, including SCSS partials, JavaScript components, and a Gulp build system. Planning and architecture validation were supported by generative AI tools (ChatGPT), used responsibly as an assistant—not a replacement—for the developer's own code.

All code is original and fully understood by the author.

📇 Author

Marcus M. CookSenior Full Stack DeveloperLinkedIn · marcusmcook@outlook.com · 701.740.4733

