# UND Web Developer Showcase – Project Walkthrough Summary

This is a summary of the development process and key features implemented in the *"Leading with Purpose"* showcase project, prepared for the final interview presentation.

---

## 🎯 Project Goals

- Create a professional, accessible, and responsive mini-site for a UND social media campaign
- Highlight front-end skills including HTML, CSS/SCSS, JavaScript, responsive UI, accessibility, and branding
- Emphasize maintainability, client-focused UI/UX, and compliance with university standards

---

## 🧩 Key Features

### 🔷 Semantic HTML5 Structure
- Used proper `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, and `<footer>` elements
- Logical heading structure (`<h1>`, `<h2>`, etc.)
- Clear landmarks for assistive technologies

### 🔷 Responsive Design
- Mobile-first layout with media queries
- Burger menu implemented with ARIA support and keyboard accessibility
- Layout adapts cleanly across screen sizes

### 🔷 President’s Endorsement Section
- Right-aligned photo (contrasts with main UND site for distinction)
- Accessible headings and image alt text
- Styled in alignment with UND visual branding

### 🔷 Social Media Posts Section
- Pulls posts from UND’s demo API
- Filters posts by message, author, username, and location
- Pagination and user-selectable post count per page
- Dynamically rendered DOM elements with semantic structure

---

## ♿ Accessibility Highlights

- WCAG 2.1 AA and Section 508 principles followed
- Keyboard navigation fully supported
- Focus styles, readable font sizes, strong contrast
- ARIA roles for nav toggle (`aria-expanded`, etc.)
- `accessibility_test.md` included to summarize manual audit

---

## 🛠 Technologies Used

- HTML5, SCSS (compiled with Gulp), Vanilla JavaScript (ES6)
- Modular, component-based structure
- No frameworks — built for clarity, speed, and flexibility

---

## 🧾 Compliance

- `compliance.md` included with detailed notes on accessibility, SEO, branding, and secure front-end practices
- Uses official UND links, colors, and logo
- Matches tone and layout patterns of und.edu

---

## 📄 Supporting Files

- `README.md` – Setup, features, build instructions
- `planning.md` – Project structure and approach
- `compliance.md` – Standards adherence and checklist

---

## 💬 Closing Note

This project reflects UND’s commitment to accessibility, innovation, and user-first digital design. I’ve aimed to demonstrate my attention to detail, ability to deliver maintainable code, and respect for institutional branding.

