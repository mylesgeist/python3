#!/usr/bin/python

import os
import datetime as datetime
import csv

print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
print("###############################################################################################################")
print("######                                                                                                    #####")
print("######                        Starting the Northern Light Python Test Script                                     #####")
print("######                                                                                                    #####")
print("###############################################################################################################")
print("---------------------------------------------------------------------------------------------------------------")
print("")

# Set system attributes
now = datetime.datetime.now()
year = now.strftime("%Y")
date_now = now.strftime("%Y-%m-%d")
current_date = datetime.datetime.today()
print('Current Date = ' + str(current_date))
os.sep = """/"""

# Set Directories
in_files_dir = './InFiles'
out_files_dir = './OutFiles'
in_file1 = str(in_files_dir) + '/in-data-1.txt'
in_file2 = str(in_files_dir) + '/in-data-2.txt'
outfile1 = str(out_files_dir) + '/out-data-1.txt'
outfile2 = str(out_files_dir) + '/out-data-2.txt'

in_file1_list = []
in_file2_list = []

def create_in_file1_words():
    # Used to create initial data-1 file to seperate the words, get rid of duplicates and sort them.
    new_word_list_1 = []
    open_infile_1 = open(in_file1, 'r')
    words_line = open_infile_1.readline().strip('\n')
    word_list_1 = words_line.split()
    word_list_1.sort()
    for all_words_1 in word_list_1:
        if len(all_words_1) >= 1:
            if all_words_1.isalnum():
                if all_words_1 not in new_word_list_1:
                    new_word_list_1.append(all_words_1)
                    # print(all_words_1)
    open_outfile_1 = open(outfile1, 'w')
    for all_lines in new_word_list_1:
        open_outfile_1.write("%s\n" % all_lines)
    open_infile_1.close()
    open_outfile_1.close()


def create_in_file2_words():
    # Used to create initial data-1 file to seperate the words, get rid of duplicates and sort them.
    new_word_list_2 = []
    open_infile_2 = open(in_file2, 'r')
    words_line = open_infile_2.readline().strip('\n')
    word_list_2 = words_line.split()
    word_list_2.sort()
    for all_words_2 in word_list_2:
        if len(all_words_2) >= 1:
            if all_words_2.isalnum():
                if all_words_2 not in new_word_list_2:
                    new_word_list_2.append(all_words_2)
                    # print(all_words_2)
    open_outfile_2 = open(outfile2, 'w')
    for all_lines in new_word_list_2:
        open_outfile_2.write("%s\n" % all_lines)
    open_infile_2.close()
    open_outfile_2.close()


def create_in_file1_list():
    # Creates the list from the data 1 file
    global in_file1_list
    open_infile_1 = open(in_file1, 'r')
    for in_file1_row in open_infile_1:
        if len(in_file1_row) >= 1:
            in_file1_list.append(in_file1_row.strip('\n'))
    open_infile_1.close()
    return in_file1_list


def create_in_file2_list():
    # Creates the list from the data 1 file
    global in_file2_list
    open_infile_2 = open(in_file2, 'r')
    for in_file2_row in open_infile_2:
        if len(in_file2_row) >= 1:
            in_file2_list.append(in_file2_row.strip('\n'))
    open_infile_2.close()
    return in_file2_list


def create_out_file1():
    # Creates output file 1
    global in_file1_list
    global in_file2_list
    open_out_file_1 = open(outfile1, 'w')
    for all_words1 in in_file1_list:
        if all_words1 not in in_file2_list:
            open_out_file_1.write(all_words1 + '\n')


def create_out_file2():
    # Creates output file 2
    global in_file1_list
    global in_file2_list
    open_out_file_2 = open(outfile2, 'w')
    for all_words2 in in_file2_list:
        if all_words2 not in in_file1_list:
            open_out_file_2.write(all_words2 + '\n')


# create_in_file1_words()
# create_in_file2_words()
create_in_file1_list()
create_in_file2_list()
create_out_file1()
create_out_file2()


print(" ")
print("---------------------------------------------------------------------------------------------------------------")
print("###############################################################################################################")
print("######                                                                                                    #####")
print("######                       The Northern Light Python Test Script has finished                                  #####")
print("######                                                                                                    #####")
print("###############################################################################################################")
print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")


